class AnimationAsset {
  static const String ROOT = 'assets/animation';

  static const String ANIM_LOADER = '$ROOT/anim_loader.json';
  static const String ANIM_AUTH = '$ROOT/anim_auth.json';
  static const String LOADER_AUTH = '$ROOT/loader_images.json';
  static const String SELECT_IMG = '$ROOT/select_image.json';
}
