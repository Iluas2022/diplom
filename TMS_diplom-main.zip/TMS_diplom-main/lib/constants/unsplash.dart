const String UNSPLASH_DOMAIN = 'https://api.unsplash.com';
const String CLIENT_ID = 'mOAXPrblCJtTVHJIlMcI-aneseFch3IZAIIrefu8Pzk';
