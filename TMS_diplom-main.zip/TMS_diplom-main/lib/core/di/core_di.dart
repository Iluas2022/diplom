import 'package:get_it/get_it.dart';

final GetIt appLocator = GetIt.instance;
