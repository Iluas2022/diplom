import 'package:dio/dio.dart';
import 'package:inst_project/core/di/core_di.dart';
import 'package:inst_project/data/provider/chat_provider.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';
import 'package:inst_project/data/provider/local_storage_provider_impl.dart';
import 'package:inst_project/data/provider/storage_provider.dart';
import 'package:inst_project/data/provider/unsplash_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/data/repositories/auth/auth_repository_impl.dart';
import 'package:inst_project/data/repositories/chats/chats_repository_impl.dart';
import 'package:inst_project/data/repositories/storage/storage_repository_impl.dart';
import 'package:inst_project/data/repositories/unsplash/unsplash_repository_impl.dart';
import 'package:inst_project/data/service/auth/auth_service.dart';
import 'package:inst_project/data/service/chat/chat_service.dart';
import 'package:inst_project/data/service/storage/storage_service.dart';
import 'package:inst_project/data/service/unsplash/unsplash_service.dart';
import 'package:inst_project/domain/repository/auth_repository/auth_repository.dart';
import 'package:inst_project/domain/repository/chats/chats_repository.dart';
import 'package:inst_project/domain/repository/storage/storage_repository.dart';
import 'package:inst_project/domain/repository/unsplash_repository.dart/unsplash_repository.dart';

class DataDi {
  void setup() {
    Dio dio = Dio();

    final UnsplashService unsplashService = UnsplashService();
    unsplashService.init(dio);

    StorageService storageService = StorageService();

    ChatService chatService = ChatService();

    initLocalSecureStorage();

    appLocator.registerSingleton<AuthService>(AuthService());

    appLocator.registerSingleton<StorageService>(storageService);

    appLocator.registerSingleton<UnsplashService>(unsplashService);

    appLocator.registerLazySingleton(() => UserProvider());

    appLocator.registerLazySingleton(() => ChatProvider());

    appLocator.registerLazySingleton(() => UnsplashImageProvider());

    appLocator.registerLazySingleton(() => StorageProvider());

    appLocator.registerFactory<AuthRepository>(
      () => AuthRepositoryImpl(
        service: appLocator.get<AuthService>(),
      ),
    );

    appLocator.registerFactory<StorageRepository>(
      () => StorageRepositoryImpl(
        service: storageService,
      ),
    );

    appLocator.registerFactory<UnsplashRepository>(
      () => UnsplashRepositoryImpl(
        service: unsplashService,
      ),
    );

    appLocator.registerFactory<ChatsRepository>(
      () => ChatsRepositoryImpl(
        service: chatService,
      ),
    );
  }

  initLocalSecureStorage() {
    final LocalSecureStorageProvider secureStorageProvider =
        LocalStorageProviderImpl();
    secureStorageProvider.init();
    appLocator
        .registerSingleton<LocalSecureStorageProvider>(secureStorageProvider);
  }
}
