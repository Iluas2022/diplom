import 'package:inst_project/data/models/user_model.dart';

class Feed {
  final String id;
  final Post post;

  const Feed(this.id, this.post);

  Map<String, dynamic> toJson() {
    return {'id': id, 'post': post.toJson()};
  }
}

class Post {
  String? title;
  List<PhotoPost>? photoPost;
  UserModel? userModel;
  List<String> userIdLike = [];

  Post(
    this.title,
    this.photoPost,
    this.userModel,
    this.userIdLike,
  );

  Post.fromJson(Map<String, dynamic> data) {
    List<PhotoPost> photos = [];
    if (data['photoPost'] != null) {
      data['photoPost'].forEach((v) {
        photos.add(PhotoPost.fromJson(v));
      });
    }
    userIdLike = [];
    if (data['userIdLike'] != null) {
      data['userIdLike'].forEach((v) {
        userIdLike.add(v);
      });
    }
    title = data['title'];
    photoPost = photos;
    userModel = UserModel.fromJson(data['userModel']);
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'photoPost': photoPost?.map((e) => e.toJson()).toList(),
      'userModel': userModel?.toJson(),
      'userIdLike': userIdLike
    };
  }
}

class PhotoPost {
  String? url;
  String? blurHash;

  PhotoPost(
    this.url,
    this.blurHash,
  );

  Map<String, dynamic> toJson() {
    return {'url': url, 'blurHash': blurHash};
  }

  PhotoPost.fromJson(Map<String, dynamic> data) {
    url = data['url'];
    blurHash = data['blurHash'];
  }
}
