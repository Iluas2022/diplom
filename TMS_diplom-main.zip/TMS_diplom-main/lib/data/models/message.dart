class Message {
  String userId;
  String message;
  String avatar;
  String name;
  DateTime createAt;

  Message({
    required this.userId,
    required this.message,
    required this.avatar,
    required this.name,
    required this.createAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'message': message,
      'avatar': avatar,
      'name': name,
      'createAt': createAt.toIso8601String(),
    };
  }

  static Message fromJson(Map<String, dynamic> json) {
    return Message(
      userId: json['userId'],
      message: json['message'],
      avatar: json['avatar'],
      name: json['name'],
      createAt: DateTime.parse(json['createAt']),
    );
  }
}
