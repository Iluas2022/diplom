import 'package:firebase_auth/firebase_auth.dart';

class UserModel {
  final String uid;
  final String name;
  final String email;
  final String phone;
  final String photo;

  const UserModel(
    this.uid,
    this.name,
    this.email,
    this.phone,
    this.photo,
  );

  static UserModel mapperFromFirebase(User user) {
    return UserModel(
      user.uid,
      user.displayName ?? '',
      user.email ?? '',
      user.phoneNumber ?? '',
      user.photoURL ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'name': name,
        'email': email,
        'phone': phone,
        'photo': photo
      };

  String toJsonMapper() {
    return '{"uid": "$uid", "name": "$name", "email": "$email", "phone": "$phone", "photo": "$photo"}';
  }

  static UserModel fromJson(Map<String, dynamic> data) {
    return UserModel(
      data['uid'] ?? '',
      data['name'] ?? '',
      data['email'] ?? '',
      data['phone'] ?? '',
      data['photo'] ?? '',
    );
  }
}
