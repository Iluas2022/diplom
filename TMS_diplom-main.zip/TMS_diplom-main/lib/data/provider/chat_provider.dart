import 'package:flutter/material.dart';
import 'package:inst_project/data/models/message.dart';
import 'package:inst_project/data/models/user_model.dart';

class ChatProvider extends ChangeNotifier {
  final List<Message> _message = [];
  List<Message> get message => _message;

  final List<UserModel> _users = [];
  List<UserModel> get users => _users;

  updateUsers(List<UserModel> value) {
    _users.clear();
    _users.addAll(value.reversed);
    notifyListeners();
  }

  updateMessages(List<Message> value) {
    _message.clear();

    value.sort((stateA, stateB) {
      return stateB.createAt.compareTo(stateA.createAt);
    });

    _message.addAll(value);
    notifyListeners();
  }

  clearMessages() {
    _message.clear();
  }

  clearUsers() {
    _users.clear();
  }
}
