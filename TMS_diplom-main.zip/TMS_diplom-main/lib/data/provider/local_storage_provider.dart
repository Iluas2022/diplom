abstract class LocalSecureStorageProvider {
  init();

  Future deleteAll();

  Future<String?> getUser();

  Future setUser(String user);
}
