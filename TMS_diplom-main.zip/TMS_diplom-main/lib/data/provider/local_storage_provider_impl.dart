import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';

class LocalStorageProviderImpl implements LocalSecureStorageProvider {
  static const String userKey = 'user';
  late FlutterSecureStorage storage;

  @override
  void init() {
    storage = const FlutterSecureStorage();
  }

  @override
  Future deleteAll() async {
    await storage.deleteAll();
  }

  @override
  Future<String?> getUser() async {
    return await storage.read(key: userKey);
  }

  @override
  Future setUser(String user) async {
    await storage.write(key: userKey, value: user);
  }
}
