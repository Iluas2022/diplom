import 'package:flutter/material.dart';
import 'package:inst_project/data/models/feed.dart';

class StorageProvider extends ChangeNotifier {
  final List<Feed> _posts = [];

  List<Feed> get posts => _posts;

  updatePosts(List<Feed> posts) {
    _posts.clear();
    _posts.addAll(posts.reversed);
    notifyListeners();
  }

  clear() {
    _posts.clear();
  }
}
