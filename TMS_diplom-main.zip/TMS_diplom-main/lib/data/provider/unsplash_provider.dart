import 'package:flutter/material.dart';
import 'package:inst_project/data/models/unsplash_image.dart';

class UnsplashImageProvider extends ChangeNotifier {
  final List<UnsplashImage> _images = [];
  final List<UnsplashImage> _selectedPhotos = [];

  List<UnsplashImage> get images => _images;
  List<UnsplashImage> get selectedPhotos => _selectedPhotos;

  bool photoIsSeleted(UnsplashImage image) {
    int index = _selectedPhotos.indexWhere((e) => e.id == image.id);

    if (index != -1) {
      return true;
    } else {
      return false;
    }
  }

  setImages(List<UnsplashImage> images) {
    _images.addAll(images);
    notifyListeners();
  }

  updateSelectedPhotos(UnsplashImage image) {
    int index = _selectedPhotos.indexWhere((e) => e.id == image.id);

    if (index != -1) {
      _selectedPhotos.removeAt(index);
    } else {
      _selectedPhotos.add(image);
    }
    notifyListeners();
  }

  clear() {
    _images.clear();
    _selectedPhotos.clear();
  }
}
