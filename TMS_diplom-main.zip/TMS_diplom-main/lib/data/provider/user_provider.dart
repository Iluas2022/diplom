import 'package:flutter/material.dart';
import 'package:inst_project/data/models/user_model.dart';

class UserProvider extends ChangeNotifier {
  UserModel? _user;

  UserModel? get user => _user;

  setUser(UserModel user) {
    _user = user;
  }

  logOut() {
    _user = null;
  }
}
