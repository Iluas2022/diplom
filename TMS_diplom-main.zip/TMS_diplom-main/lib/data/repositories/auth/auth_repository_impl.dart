import 'package:inst_project/data/service/auth/auth_service.dart';
import 'package:inst_project/domain/entity/response/auth_response.dart';
import 'package:inst_project/domain/repository/auth_repository/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  final AuthService _service;

  AuthRepositoryImpl({required AuthService service}) : _service = service;

  @override
  Future<AuthResult> signUpWithGoogle() async {
    return await _service.signInWithGoogle();
  }

  @override
  Future<AuthResult> signUpEmailPassword(String email, String password) async {
    return await _service.signUpEmailPassword(email, password);
  }

  @override
  Future<AuthResult> signInEmailPassword(String email, String password) async {
    return await _service.signInEmailPassword(email, password);
  }
}
