import 'package:inst_project/data/models/message.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/data/service/chat/chat_service.dart';
import 'package:inst_project/domain/repository/chats/chats_repository.dart';

class ChatsRepositoryImpl implements ChatsRepository {
  final ChatService _service;

  ChatsRepositoryImpl({required ChatService service}) : _service = service;

  @override
  Future<List<Message>> getMessages(String userId) async {
    return await _service.getMessages(userId);
  }

  @override
  Future<void> sendMessage(Message message) async {
    await _service.sendMessage(message);
  }

  @override
  Future<List<UserModel>> getUsers() async {
    return await _service.getUsers();
  }
}
