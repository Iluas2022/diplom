import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/data/service/storage/storage_service.dart';
import 'package:inst_project/domain/repository/storage/storage_repository.dart';

class StorageRepositoryImpl implements StorageRepository {
  final StorageService _service;

  StorageRepositoryImpl({required StorageService service}) : _service = service;

  @override
  Future<void> saveResult(Feed feed) async {
    return await _service.saveResult(feed);
  }

  @override
  Future<List<Feed>> getCollection() async {
    return await _service.getCollection();
  }

  @override
  Future<void> updateFeed(Feed feed) async {
    return await _service.updateFeed(feed);
  }

  @override
  Future<void> saveUserFBDB(UserModel user) async {
    await _service.saveUserFBDB(user);
  }
}
