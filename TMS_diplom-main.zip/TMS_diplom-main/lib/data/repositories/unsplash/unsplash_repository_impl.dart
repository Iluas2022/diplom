import 'package:inst_project/data/models/unsplash_image.dart';
import 'package:inst_project/data/service/unsplash/unsplash_service.dart';
import 'package:inst_project/domain/repository/unsplash_repository.dart/unsplash_repository.dart';

class UnsplashRepositoryImpl implements UnsplashRepository {
  final UnsplashService _service;

  UnsplashRepositoryImpl({required UnsplashService service})
      : _service = service;

  @override
  Future<List<UnsplashImage>> getImages(int page) async {
    return await _service.getImages(page);
  }
}
