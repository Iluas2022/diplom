import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:inst_project/constants/google.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/domain/entity/response/auth_response.dart';

class AuthService {
  static final FirebaseAuth _firebaseAuthInstance = FirebaseAuth.instance;

  Future<AuthResult> signInWithGoogle() async {
    final GoogleSignInAccount? googleUser =
        await GoogleSignIn(clientId: clientIdIos).signIn();

    if (googleUser == null) throw ('Google signIn cancelled');

    final GoogleSignInAuthentication googleAuth =
        await googleUser.authentication;

    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    UserCredential userCredential =
        await _firebaseAuthInstance.signInWithCredential(credential);

    if (userCredential.user == null) {
      throw ('Google signIn UserCredential == null');
    }

    UserModel user = UserModel.mapperFromFirebase(userCredential.user!);

    return AuthSuccess(user);
  }

  Future<AuthResult> signUpEmailPassword(String email, String password) async {
    try {
      final userCredential = await _firebaseAuthInstance
          .createUserWithEmailAndPassword(email: email, password: password);

      print('signUpEmailPassword ${userCredential.user}');

      if (userCredential.user == null) {
        throw ('signUpEmailPassword UserCredential == null');
      }

      UserModel user = UserModel.mapperFromFirebase(userCredential.user!);

      return AuthSuccess(user);
    } catch (e) {
      if (e is FirebaseAuthException) {
        return AuthError(e.message ?? '');
      } else {
        return AuthError(e.toString());
      }
    }
  }

  Future<AuthResult> signInEmailPassword(String email, String password) async {
    try {
      final userCredential = await _firebaseAuthInstance
          .signInWithEmailAndPassword(email: email, password: password);

      print('signInEmailPassword ${userCredential.user}');

      if (userCredential.user == null) {
        throw ('signInEmailPassword UserCredential == null');
      }

      UserModel user = UserModel.mapperFromFirebase(userCredential.user!);

      return AuthSuccess(user);
    } catch (e) {
      if (e is FirebaseAuthException) {
        return AuthError(e.message ?? '');
      } else {
        return AuthError(e.toString());
      }
    }
  }
}
