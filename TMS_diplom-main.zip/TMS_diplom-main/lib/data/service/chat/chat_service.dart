import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:inst_project/data/models/message.dart';
import 'package:inst_project/data/models/user_model.dart';

class ChatService {
  static final FirebaseFirestore _firebaseFirestore =
      FirebaseFirestore.instance;

  Future<List<UserModel>> getUsers() async {
    final CollectionReference<Map<String, dynamic>> postCollection =
        _firebaseFirestore.collection('users');

    QuerySnapshot querySnapshot = await postCollection.get();
    List<UserModel> users = querySnapshot.docs.map(
      (doc) {
        final json = doc.data() as Map<String, dynamic>;
        return UserModel.fromJson(json);
      },
    ).toList();

    return users;
  }

  Future<List<Message>> getMessages(String userId) async {
    final CollectionReference<Map<String, dynamic>> postCollection =
        _firebaseFirestore.collection('chats/$userId/messages');

    QuerySnapshot querySnapshot = await postCollection.get();
    List<Message> messages = querySnapshot.docs.map(
      (doc) {
        final json = doc.data() as Map<String, dynamic>;
        return Message.fromJson(json);
      },
    ).toList();

    return messages;
  }

  Future<void> sendMessage(Message message) async {
    final CollectionReference<Map<String, dynamic>> postCollection =
        _firebaseFirestore.collection('chats/${message.userId}/messages');
    await postCollection.add(message.toJson());
  }
}
