import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/data/models/user_model.dart';

class StorageService {
  static final FirebaseFirestore _firebaseFirestore =
      FirebaseFirestore.instance;

  final String feedKey = 'feeds';
  final String usersKey = 'users';

  Future saveResult(Feed feed) async {
    final CollectionReference<Map<String, dynamic>> postCollection =
        _firebaseFirestore.collection(feedKey);
    await postCollection.doc(feed.id).set(feed.post.toJson());
  }

  Future<List<Feed>> getCollection() async {
    final CollectionReference<Map<String, dynamic>> postCollection =
        _firebaseFirestore.collection(feedKey);
    QuerySnapshot querySnapshot = await postCollection.get();
    List<Feed> feeds = querySnapshot.docs.map(
      (doc) {
        final json = doc.data() as Map<String, dynamic>;
        return Feed(doc.id, Post.fromJson(json));
      },
    ).toList();

    return feeds;
  }

  Future<void> updateFeed(Feed feed) async {
    final CollectionReference<Map<String, dynamic>> postCollection =
        _firebaseFirestore.collection(feedKey);
    await postCollection.doc(feed.id).update(feed.post.toJson());
  }

  Future<void> saveUserFBDB(UserModel user) async {
    final CollectionReference<Map<String, dynamic>> postCollection =
        _firebaseFirestore.collection(usersKey);
    await postCollection.doc(user.uid).set(user.toJson());
  }
}
