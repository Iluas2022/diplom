import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:inst_project/constants/unsplash.dart';
import 'package:inst_project/data/models/unsplash_image.dart';

class UnsplashService {
  static const int questionLimit = 5;
  late final Dio _dio;

  init(Dio dio) {
    _dio = dio;
  }

  Future<List<UnsplashImage>> getImages(int page) async {
    List<UnsplashImage> imageUnsplash = [];
    try {
      final res = await _dio.get(
          '$UNSPLASH_DOMAIN/photos?client_id=$CLIENT_ID&page=$page&utm_source=inst');

      for (var item in res.data) {
        imageUnsplash.add(UnsplashImage.fromJson(item));
      }
    } catch (e) {
      log('getImages() error $e');
    }

    return imageUnsplash;
  }
}
