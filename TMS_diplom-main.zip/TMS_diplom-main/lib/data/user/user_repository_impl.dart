import 'dart:convert';

import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';
import 'package:inst_project/domain/repository/user_repository/user_repository.dart';

class UserRepositoryImpl implements UserRepository {
  final LocalSecureStorageProvider _secureStorageProvider;

  UserRepositoryImpl(
      {required LocalSecureStorageProvider secureStorageProvider})
      : _secureStorageProvider = secureStorageProvider;

  @override
  Future<UserModel> getUser() async {
    String? userStr = await _secureStorageProvider.getUser();
    return UserModel.fromJson(jsonDecode(userStr!));
  }
}
