import 'package:inst_project/data/models/user_model.dart';

class AuthResult {}

class AuthSuccess extends AuthResult {
  final UserModel userModel;

  AuthSuccess(this.userModel);
}

class AuthError extends AuthResult {
  String error;

  AuthError(this.error);
}
