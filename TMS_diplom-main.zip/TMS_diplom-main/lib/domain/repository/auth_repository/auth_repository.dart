import 'package:inst_project/domain/entity/response/auth_response.dart';

abstract interface class AuthRepository {
  Future<AuthResult> signUpWithGoogle();

  Future<AuthResult> signUpEmailPassword(String email, String password);

  Future<AuthResult> signInEmailPassword(String email, String password);
}
