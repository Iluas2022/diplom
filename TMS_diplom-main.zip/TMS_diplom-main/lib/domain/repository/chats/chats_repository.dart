import 'package:inst_project/data/models/message.dart';
import 'package:inst_project/data/models/user_model.dart';

abstract interface class ChatsRepository {
  Future<List<Message>> getMessages(String userId);

  Future<void> sendMessage(Message message);

  Future<List<UserModel>> getUsers();
}
