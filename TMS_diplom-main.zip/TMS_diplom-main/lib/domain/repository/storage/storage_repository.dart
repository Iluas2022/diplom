import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/data/models/user_model.dart';

abstract interface class StorageRepository {
  Future<void> saveResult(Feed feed);

  Future<List<Feed>> getCollection();

  Future<void> updateFeed(Feed feed);

  Future<void> saveUserFBDB(UserModel user);
}
