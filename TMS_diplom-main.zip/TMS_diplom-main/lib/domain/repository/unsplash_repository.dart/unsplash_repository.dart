import 'package:inst_project/data/models/unsplash_image.dart';

abstract interface class UnsplashRepository {
  Future<List<UnsplashImage>> getImages(int page);
}
