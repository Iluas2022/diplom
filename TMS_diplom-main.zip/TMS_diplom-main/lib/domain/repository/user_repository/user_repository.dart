import 'package:inst_project/data/models/user_model.dart';

abstract interface class UserRepository {
  Future<UserModel> getUser();
}
