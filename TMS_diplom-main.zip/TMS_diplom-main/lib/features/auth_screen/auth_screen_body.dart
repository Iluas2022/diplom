import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/constants/animations.dart';
import 'package:inst_project/features/auth_screen/bloc/sign_up_bloc.dart';
import 'package:inst_project/features/auth_screen/widgets/auth_button.dart';
import 'package:inst_project/router.dart' as router;
import 'package:lottie/lottie.dart';

class AuthScreenBody extends StatelessWidget {
  const AuthScreenBody({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SignUpBloc, SignUpState>(
      buildWhen: (previous, current) => buildWhen(previous, current, context),
      builder: (context, snapshot) {
        return Scaffold(
          backgroundColor: Colors.black,
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(),
                Lottie.asset(
                  AnimationAsset.ANIM_AUTH,
                  repeat: false,
                ),
                const Text(
                  'Hello, dear friend',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 20),
                ButtonAuth(
                  title: 'Sign In',
                  onPressed: () {
                    Navigator.of(context).pushNamed(router.Router.signIn);
                  },
                ),
                const SizedBox(height: 10),
                ButtonAuth(
                  title: 'Sign Up',
                  onPressed: () {
                    Navigator.of(context).pushNamed(router.Router.signUp);
                  },
                ),
                const SizedBox(height: 10),
                ButtonAuth(
                  title: 'Sign In with Google',
                  onPressed: () {
                    BlocProvider.of<SignUpBloc>(context)
                        .add(SignUpWithGoogle());
                  },
                ),
                const Spacer(flex: 2),
              ],
            ),
          ),
        );
      },
    );
  }

  bool buildWhen(
    SignUpState previous,
    SignUpState current,
    BuildContext context,
  ) {
    if (current is SignUpRoute) {
      Navigator.pushNamedAndRemoveUntil(context, current.route, (_) => false);
    } else if (current is SignUpErrorMessage) {
      final scaffold = ScaffoldMessenger.of(context);
      scaffold.showSnackBar(SnackBar(content: Text(current.message)));
    }
    return false;
  }
}
