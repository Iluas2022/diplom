import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/domain/entity/response/auth_response.dart';
import 'package:inst_project/domain/repository/auth_repository/auth_repository.dart';
import 'package:inst_project/domain/repository/storage/storage_repository.dart';
import 'package:inst_project/router.dart';

part 'sign_up_event.dart';
part 'sign_up_state.dart';

class SignUpBloc extends Bloc<SignUpEvent, SignUpState> {
  late final AuthRepository _authRepository;
  late final UserProvider _userProvider;
  late final LocalSecureStorageProvider _secureStorageProvider;
  late final StorageRepository _storageRepository;

  SignUpBloc({
    required AuthRepository authRepository,
    required UserProvider userProvider,
    required LocalSecureStorageProvider secureStorageProvider,
    required StorageRepository storageRepository,
  })  : _authRepository = authRepository,
        _userProvider = userProvider,
        _secureStorageProvider = secureStorageProvider,
        _storageRepository = storageRepository,
        super(SignUpState()) {
    on<SignUpWithGoogle>(_signUpWithGoogle);
    on<SignUpEmailPassword>(_signUpEmailPassword);
    on<SignInEmailPassword>(_signInEmailPassword);
  }

  _signUpWithGoogle(event, emit) async {
    AuthResult result = await _authRepository.signUpWithGoogle();
    if (result is AuthSuccess) {
      _userProvider.setUser(result.userModel);
      await _secureStorageProvider.setUser(result.userModel.toJsonMapper());
      await _storageRepository.saveUserFBDB(result.userModel);
      emit(SignUpRoute(Router.mainPage));
    } else if (result is AuthError) {
      emit(SignUpErrorMessage(result.error));
    }
  }

  _signUpEmailPassword(SignUpEmailPassword event, emit) async {
    AuthResult result = await _authRepository.signUpEmailPassword(
      event.email,
      event.password,
    );
    if (result is AuthSuccess) {
      _userProvider.setUser(result.userModel);
      await _secureStorageProvider.setUser(result.userModel.toJsonMapper());
      await _storageRepository.saveUserFBDB(result.userModel);
      emit(SignUpRoute(Router.mainPage));
    } else if (result is AuthError) {
      emit(SignUpErrorMessage(result.error));
    }
  }

  _signInEmailPassword(SignInEmailPassword event, emit) async {
    AuthResult result = await _authRepository.signInEmailPassword(
      event.email,
      event.password,
    );
    if (result is AuthSuccess) {
      _userProvider.setUser(result.userModel);
      await _secureStorageProvider.setUser(result.userModel.toJsonMapper());
      emit(SignUpRoute(Router.mainPage));
    } else if (result is AuthError) {
      emit(SignUpErrorMessage(result.error));
    }
  }
}
