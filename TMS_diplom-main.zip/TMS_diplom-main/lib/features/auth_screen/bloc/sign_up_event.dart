part of 'sign_up_bloc.dart';

class SignUpEvent {}

class SignUpWithGoogle extends SignUpEvent {}

class SignUpEmailPassword extends SignUpEvent {
  String email;
  String password;

  SignUpEmailPassword({
    required this.email,
    required this.password,
  });
}

class SignInEmailPassword extends SignUpEvent {
  String email;
  String password;

  SignInEmailPassword({
    required this.email,
    required this.password,
  });
}
