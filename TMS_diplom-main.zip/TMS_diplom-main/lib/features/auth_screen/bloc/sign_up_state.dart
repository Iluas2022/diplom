part of 'sign_up_bloc.dart';

class SignUpState {}

class SignUpRoute extends SignUpState {
  String route;

  SignUpRoute(this.route);
}

class SignUpErrorMessage extends SignUpState {
  String message;

  SignUpErrorMessage(this.message);
}
