import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/core/di/core_di.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/domain/repository/auth_repository/auth_repository.dart';
import 'package:inst_project/domain/repository/storage/storage_repository.dart';
import 'package:inst_project/features/auth_screen/bloc/sign_up_bloc.dart';
import 'package:inst_project/features/auth_screen/sign_in_email_password_body.dart';

class SignInEmailPasswordScreen extends StatelessWidget {
  const SignInEmailPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<SignUpBloc>(
      create: (ctx) => SignUpBloc(
        authRepository: appLocator.get<AuthRepository>(),
        userProvider: appLocator.get<UserProvider>(),
        secureStorageProvider: appLocator.get<LocalSecureStorageProvider>(),
        storageRepository: appLocator.get<StorageRepository>(),
      ),
      child: const SignInEmailPasswordScreenBody(),
    );
  }
}
