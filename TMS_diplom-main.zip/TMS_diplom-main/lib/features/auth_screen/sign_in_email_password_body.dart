import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/features/auth_screen/bloc/sign_up_bloc.dart';
import 'package:inst_project/features/auth_screen/widgets/auth_button.dart';

class SignInEmailPasswordScreenBody extends StatefulWidget {
  const SignInEmailPasswordScreenBody({super.key});

  @override
  State<SignInEmailPasswordScreenBody> createState() =>
      _SignInEmailPasswordScreenBodyState();
}

class _SignInEmailPasswordScreenBodyState
    extends State<SignInEmailPasswordScreenBody> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SignUpBloc, SignUpState>(
      buildWhen: (previous, current) => buildWhen(previous, current, context),
      builder: (context, snapshot) {
        return Scaffold(
          backgroundColor: Colors.black,
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Sign In',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    hintText: 'Email',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  style: const TextStyle(color: Colors.white),
                  textInputAction: TextInputAction.done,
                  minLines: 1,
                  maxLines: 4,
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  style: const TextStyle(color: Colors.white),
                  textInputAction: TextInputAction.done,
                  minLines: 1,
                  maxLines: 4,
                ),
                const SizedBox(height: 40),
                ButtonAuth(
                  title: 'Continue',
                  onPressed: () {
                    BlocProvider.of<SignUpBloc>(context).add(
                      SignInEmailPassword(
                        email: _emailController.text,
                        password: _passwordController.text,
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  bool buildWhen(
    SignUpState previous,
    SignUpState current,
    BuildContext context,
  ) {
    if (current is SignUpRoute) {
      Navigator.pushNamedAndRemoveUntil(context, current.route, (_) => false);
    } else if (current is SignUpErrorMessage) {
      final scaffold = ScaffoldMessenger.of(context);
      scaffold.showSnackBar(SnackBar(content: Text(current.message)));
    }
    return false;
  }
}
