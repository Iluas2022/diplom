part of 'main_screen_bloc.dart';

class MainScreenEvent {}

// class SignUpWithGoogle extends MainScreenEvent {}
