part of 'main_screen_bloc.dart';

class MainScreenState {}

class MainScreenRoute extends MainScreenState {
  String route;

  MainScreenRoute(this.route);
}
