import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/core/di/core_di.dart';
import 'package:inst_project/domain/repository/storage/storage_repository.dart';
import 'package:inst_project/domain/repository/unsplash_repository.dart/unsplash_repository.dart';
import 'package:inst_project/features/main_screen/features/add_screen/add_screen_body.dart';
import 'package:inst_project/features/main_screen/features/add_screen/bloc/add_screen_bloc.dart';

class AddScreen extends StatelessWidget {
  const AddScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<AddScreenBloc>(
      create: (ctx) => AddScreenBloc(
        unsplashRepository: appLocator.get<UnsplashRepository>(),
        storageRepository: appLocator.get<StorageRepository>(),
      ),
      child: const AddScreenBody(),
    );
  }
}
