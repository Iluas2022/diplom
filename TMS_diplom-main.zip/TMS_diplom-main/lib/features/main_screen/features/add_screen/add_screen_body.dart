import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:inst_project/constants/animations.dart';
import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/data/models/unsplash_image.dart';
import 'package:inst_project/data/provider/unsplash_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/features/main_screen/features/add_screen/bloc/add_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/add_screen/widgets/app_bar.dart';
import 'package:inst_project/features/main_screen/features/add_screen/widgets/grid_images.dart';
import 'package:inst_project/features/main_screen/features/add_screen/widgets/text_field.dart';
import 'package:lottie/lottie.dart';

class AddScreenBody extends StatefulWidget {
  const AddScreenBody({super.key});

  @override
  State<AddScreenBody> createState() => _AddScreenBodyState();
}

class _AddScreenBodyState extends State<AddScreenBody> {
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _textEditingController = TextEditingController();
  final UserProvider userProvider = GetIt.I.get<UserProvider>();
  final UnsplashImageProvider unsplashImageProvider =
      GetIt.I.get<UnsplashImageProvider>();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(
      () {
        if (_scrollController.offset >=
            _scrollController.position.maxScrollExtent) {
          BlocProvider.of<AddScreenBloc>(context).add(GetImages());
        }
      },
    );
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AddScreenBloc, AddScreenState>(
        buildWhen: (previous, current) => buildWhen(previous, current, context),
        builder: (context, snapshot) {
          List<UnsplashImage> images =
              context.watch<UnsplashImageProvider>().images;

          return Scaffold(
            appBar: CustomAppBar(
              onPressed: () {
                List<PhotoPost> photos = unsplashImageProvider.selectedPhotos
                    .map(
                      (e) => PhotoPost(
                        e.urls?.regular,
                        e.blurHash,
                      ),
                    )
                    .toList();
                BlocProvider.of<AddScreenBloc>(context).add(
                  CreatePost(
                    Feed(
                      DateTime.now().toIso8601String(),
                      Post(
                        _textEditingController.text,
                        photos,
                        userProvider.user!,
                        [],
                      ),
                    ),
                  ),
                );
              },
            ),
            body: images.isEmpty
                ? Center(
                    child: Lottie.asset(
                      AnimationAsset.LOADER_AUTH,
                      repeat: true,
                    ),
                  )
                : Column(
                    children: [
                      const SizedBox(height: 20),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: CustomTextField(
                          textEditingController: _textEditingController,
                        ),
                      ),
                      const SizedBox(height: 40),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: GridImages(
                            controller: _scrollController,
                            images: images,
                            onTap: (image) {
                              BlocProvider.of<AddScreenBloc>(context)
                                  .add(SelectedPhoto(image));
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
          );
        });
  }

  bool buildWhen(
    AddScreenState previous,
    AddScreenState current,
    BuildContext context,
  ) {
    if (current is AddRoute) {
      Navigator.pushNamedAndRemoveUntil(context, current.route, (_) => false);
    }
    return false;
  }
}
