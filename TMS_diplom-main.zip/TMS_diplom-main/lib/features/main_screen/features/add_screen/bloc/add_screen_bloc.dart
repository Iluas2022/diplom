import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/data/models/unsplash_image.dart';
import 'package:inst_project/data/provider/unsplash_provider.dart';
import 'package:inst_project/domain/repository/storage/storage_repository.dart';
import 'package:inst_project/domain/repository/unsplash_repository.dart/unsplash_repository.dart';
import 'package:inst_project/router.dart';

part 'add_screen_event.dart';
part 'add_screen_state.dart';

class AddScreenBloc extends Bloc<AddScreenEvent, AddScreenState> {
  late final UnsplashRepository _unsplashRepository;
  late final StorageRepository _storageRepository;

  int page = 1;
  bool isLoading = false;

  AddScreenBloc({
    required UnsplashRepository unsplashRepository,
    required StorageRepository storageRepository,
  })  : _unsplashRepository = unsplashRepository,
        _storageRepository = storageRepository,
        super(AddScreenState()) {
    _init();
    on<GetImages>(_getImages);
    on<SelectedPhoto>(_selectedPhoto);
    on<CreatePost>(_createPost);
  }

  final UnsplashImageProvider _unsplashImageProvider =
      GetIt.I.get<UnsplashImageProvider>();

  _init() async {
    _unsplashImageProvider.clear();
    isLoading = true;
    List<UnsplashImage> result = await _unsplashRepository.getImages(page);
    page++;
    isLoading = false;
    _unsplashImageProvider.setImages(result);
  }

  _getImages(GetImages event, emit) async {
    if (!isLoading) {
      isLoading = true;
      List<UnsplashImage> result = await _unsplashRepository.getImages(page);
      page++;
      isLoading = false;
      _unsplashImageProvider.setImages(result);
    }
  }

  _selectedPhoto(SelectedPhoto event, emit) async {
    _unsplashImageProvider.updateSelectedPhotos(event.unsplashImage);
    emit(SelectPhoto(event.unsplashImage));
  }

  _createPost(CreatePost event, emit) async {
    if (event.feed.post.title!.isNotEmpty &&
        event.feed.post.photoPost!.isNotEmpty) {
      _storageRepository.saveResult(event.feed);
      emit(AddRoute(Router.mainPage));
    }
  }
}
