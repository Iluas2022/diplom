part of 'add_screen_bloc.dart';

class AddScreenEvent {}

class GetImages extends AddScreenEvent {}

class SelectedPhoto extends AddScreenEvent {
  UnsplashImage unsplashImage;

  SelectedPhoto(this.unsplashImage);
}

class CreatePost extends AddScreenEvent {
  Feed feed;

  CreatePost(this.feed);
}
