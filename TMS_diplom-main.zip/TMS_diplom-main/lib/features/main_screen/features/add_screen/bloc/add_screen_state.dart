part of 'add_screen_bloc.dart';

class AddScreenState {}

class AddRoute extends AddScreenState {
  String route;

  AddRoute(this.route);
}

class SelectPhoto extends AddScreenState {
  UnsplashImage image;

  SelectPhoto(this.image);
}
