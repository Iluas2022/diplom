import 'package:blurhash_ffi/blurhashffi_image.dart';
import 'package:flutter/material.dart';

class CustomBlurHash extends StatelessWidget {
  final String? blurHash;
  final double? width, height;
  const CustomBlurHash({
    super.key,
    required this.blurHash,
    this.height,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Image(
      image: BlurhashFfiImage(blurHash ?? "L5H2EC=PM+yV0g-mq.wG9c010J}I"),
      fit: BoxFit.cover,
      height: height,
      width: width,
    );
  }
}
