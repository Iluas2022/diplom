import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/data/models/unsplash_image.dart';
import 'package:inst_project/data/provider/unsplash_provider.dart';
import 'package:inst_project/features/main_screen/features/add_screen/widgets/image_widget.dart';

class GridImages extends StatelessWidget {
  final ScrollController controller;
  final List<UnsplashImage> images;
  final Function(UnsplashImage) onTap;
  const GridImages({
    super.key,
    required this.controller,
    required this.images,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Select Photos',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        Expanded(
          child: GridView.builder(
            controller: controller,
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: images.length,
            padding: const EdgeInsets.symmetric(vertical: 10),
            addAutomaticKeepAlives: true,
            itemBuilder: (ctx, index) {
              UnsplashImage image = images[index];
              bool isSelected =
                  context.watch<UnsplashImageProvider>().photoIsSeleted(image);

              return GestureDetector(
                onTap: () => onTap(image),
                child: ImageWidget(
                  image: image,
                  isSelected: isSelected,
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
