import 'package:flutter/material.dart';
import 'package:inst_project/constants/animations.dart';
import 'package:inst_project/data/models/unsplash_image.dart';
import 'package:inst_project/features/main_screen/features/add_screen/widgets/blur_hash.dart';
import 'package:lottie/lottie.dart';

class ImageWidget extends StatelessWidget {
  final bool isSelected;
  final UnsplashImage image;
  const ImageWidget({
    super.key,
    required this.isSelected,
    required this.image,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          Positioned.fill(
            child: Image.network(
              image.urls!.regular!,
              fit: BoxFit.cover,
              loadingBuilder: (BuildContext context, Widget child,
                  ImageChunkEvent? loadingProgress) {
                if (loadingProgress == null) return child;
                return CustomBlurHash(blurHash: image.blurHash);
              },
            ),
          ),
          if (isSelected)
            Padding(
              padding: const EdgeInsets.only(right: 10, bottom: 10),
              child: Lottie.asset(
                AnimationAsset.SELECT_IMG,
                repeat: false,
              ),
            ),
        ],
      ),
    );
  }
}
