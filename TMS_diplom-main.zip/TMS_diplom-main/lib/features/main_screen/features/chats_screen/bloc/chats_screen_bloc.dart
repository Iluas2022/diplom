import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/data/provider/chat_provider.dart';
import 'package:inst_project/domain/repository/chats/chats_repository.dart';
import 'package:inst_project/router.dart';

part 'chats_screen_event.dart';
part 'chats_screen_state.dart';

class ChatsScreenBloc extends Bloc<ChatsScreenEvent, ChatsScreenState> {
  late final ChatsRepository _chatsRepository;
  ChatsScreenBloc({required ChatsRepository chatsRepository})
      : _chatsRepository = chatsRepository,
        super(ChatsScreenState()) {
    _init();
    on<OpenChat>(_openChat);
  }

  final ChatProvider _chatProvider = GetIt.I.get<ChatProvider>();
  // final UserProvider userProvider = GetIt.I.get<UserProvider>();

  _init() async {
    _chatProvider.clearUsers();
    _chatProvider.clearMessages();
    List<UserModel> users = await _chatsRepository.getUsers();
    _chatProvider.updateUsers(users);
  }

  _openChat(OpenChat event, emit) async {
    emit(AddRoute(Router.chatPage, event.user));
  }
}
