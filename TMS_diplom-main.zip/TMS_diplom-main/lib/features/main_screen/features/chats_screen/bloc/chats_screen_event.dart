part of 'chats_screen_bloc.dart';

class ChatsScreenEvent {}

class OpenChat extends ChatsScreenEvent {
  UserModel user;

  OpenChat(this.user);
}
