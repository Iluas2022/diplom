part of 'chats_screen_bloc.dart';

class ChatsScreenState {}

class AddRoute extends ChatsScreenState {
  String route;
  UserModel user;

  AddRoute(this.route, this.user);
}
