import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:inst_project/data/models/message.dart';
import 'package:inst_project/data/provider/chat_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/domain/repository/chats/chats_repository.dart';

part 'chat_screen_event.dart';
part 'chat_screen_state.dart';

class ChatScreenBloc extends Bloc<ChatScreenEvent, ChatScreenState> {
  late final ChatsRepository _chatsRepository;
  final String _userId;
  ChatScreenBloc({
    required ChatsRepository chatsRepository,
    required String userId,
  })  : _chatsRepository = chatsRepository,
        _userId = userId,
        super(ChatScreenState()) {
    _init();
    on<SendMessage>(_sendMessage);
  }

  final ChatProvider _chatProvider = GetIt.I.get<ChatProvider>();
  final UserProvider userProvider = GetIt.I.get<UserProvider>();

  _init() async {
    _chatProvider.clearMessages();
    List<Message> messages = await _chatsRepository.getMessages(_userId);
    _chatProvider.updateMessages(messages);
  }

  _sendMessage(SendMessage event, emit) async {
    await _chatsRepository.sendMessage(event.message);
    List<Message> messages = await _chatsRepository.getMessages(event.userId);
    _chatProvider.updateMessages(messages);
  }
}
