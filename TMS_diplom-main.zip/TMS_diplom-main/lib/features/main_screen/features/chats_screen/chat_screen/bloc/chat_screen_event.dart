part of 'chat_screen_bloc.dart';

class ChatScreenEvent {}

class SendMessage extends ChatScreenEvent {
  Message message;
  String userId;

  SendMessage(
    this.message,
    this.userId,
  );
}
