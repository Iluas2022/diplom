part of 'chat_screen_bloc.dart';

class ChatScreenState {}
