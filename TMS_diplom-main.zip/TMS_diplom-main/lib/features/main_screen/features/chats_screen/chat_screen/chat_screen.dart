import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/core/di/core_di.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/domain/repository/chats/chats_repository.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/chat_screen/bloc/chat_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/chat_screen/chat_screen_body.dart';

class ChatScreen extends StatelessWidget {
  final UserModel user;
  const ChatScreen({
    super.key,
    required this.user,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider<ChatScreenBloc>(
      create: (ctx) => ChatScreenBloc(
        chatsRepository: appLocator.get<ChatsRepository>(),
        userId: user.uid,
      ),
      child: ChatScreenBody(user: user),
    );
  }
}
