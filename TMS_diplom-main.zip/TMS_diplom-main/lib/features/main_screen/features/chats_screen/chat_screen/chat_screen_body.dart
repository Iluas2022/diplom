import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:inst_project/data/models/message.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/data/provider/chat_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/chat_screen/bloc/chat_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/chat_screen/widget/input_widget.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/chat_screen/widget/message_widget.dart';
import 'package:inst_project/features/main_screen/features/widgets/app_bar.dart';

class ChatScreenBody extends StatefulWidget {
  final UserModel user;
  const ChatScreenBody({
    super.key,
    required this.user,
  });

  @override
  State<ChatScreenBody> createState() => _ChatScreenBodyState();
}

class _ChatScreenBodyState extends State<ChatScreenBody> {
  final TextEditingController _textEditingController = TextEditingController();
  final UserProvider userProvider = GetIt.I.get<UserProvider>();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatScreenBloc, ChatScreenState>(
      buildWhen: (previous, current) => buildWhen(previous, current, context),
      builder: (context, snapshot) {
        List<Message> message = context.watch<ChatProvider>().message;

        return Scaffold(
          appBar: CustomAppBar(title: widget.user.email),
          body: SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    shrinkWrap: true,
                    reverse: true,
                    itemCount: message.length,
                    itemBuilder: (ctx, index) {
                      return MessageWidget(
                        isCurrentUser:
                            message[index].userId == userProvider.user!.uid,
                        message: message[index],
                      );
                    },
                  ),
                ),
                InputChatForm(
                  textEditingController: _textEditingController,
                  onSend: sendMessage,
                  onChanged: () => setState(() {}),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  bool buildWhen(
    ChatScreenState previous,
    ChatScreenState current,
    BuildContext context,
  ) {
    return false;
  }

  void sendMessage() {
    FocusScope.of(context).unfocus();
    BlocProvider.of<ChatScreenBloc>(context).add(
      SendMessage(
        Message(
          userId: userProvider.user!.uid,
          message: _textEditingController.text,
          avatar: userProvider.user!.photo,
          name: userProvider.user!.name,
          createAt: DateTime.now(),
        ),
        widget.user.uid,
      ),
    );
    _textEditingController.text = '';
  }
}
