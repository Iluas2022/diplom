import 'package:flutter/material.dart';

class InputChatForm extends StatelessWidget {
  final TextEditingController textEditingController;
  final VoidCallback onSend;
  final VoidCallback onChanged;
  const InputChatForm({
    super.key,
    required this.textEditingController,
    required this.onSend,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: textEditingController,
              onChanged: (value) => onChanged(),
              decoration: InputDecoration(
                hintText: 'Type ...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
              style: const TextStyle(color: Colors.black),
              textInputAction: TextInputAction.done,
              minLines: 1,
              maxLines: 3,
            ),
          ),
          const SizedBox(width: 20),
          GestureDetector(
            onTap: textEditingController.text.isEmpty ? null : onSend,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[Colors.red, Colors.blue],
                ),
              ),
              child: const Icon(Icons.send),
            ),
          ),
        ],
      ),
    );
  }
}
