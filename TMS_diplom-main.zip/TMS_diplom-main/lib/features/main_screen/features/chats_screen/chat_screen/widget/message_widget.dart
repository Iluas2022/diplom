import 'package:flutter/material.dart';
import 'package:inst_project/data/models/message.dart';

class MessageWidget extends StatelessWidget {
  final bool isCurrentUser;
  final Message message;
  const MessageWidget({
    super.key,
    required this.isCurrentUser,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    if (isCurrentUser) {
      return ListTile(
        hoverColor: Colors.red,
        title: Text(
          message.name,
          textAlign: TextAlign.end,
        ),
        subtitle: Text(
          message.message,
          textAlign: TextAlign.end,
        ),
      );
    }

    return Row(
      children: [
        message.avatar.isEmpty
            ? const Icon(
                Icons.person,
                size: 40,
              )
            : Image.network(
                message.avatar,
                fit: BoxFit.cover,
                height: 40,
                width: 40,
              ),
        Expanded(
          child: ListTile(
            title: Text(message.name),
            subtitle: Text(message.message),
          ),
        ),
      ],
    );
  }
}
