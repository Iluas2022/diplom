import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/core/di/core_di.dart';
import 'package:inst_project/domain/repository/chats/chats_repository.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/bloc/chats_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/chats_screen_body.dart';

class ChatsScreen extends StatelessWidget {
  const ChatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<ChatsScreenBloc>(
      create: (ctx) => ChatsScreenBloc(
        chatsRepository: appLocator.get<ChatsRepository>(),
      ),
      child: const ChatsScreenBody(),
    );
  }
}
