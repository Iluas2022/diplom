import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/constants/animations.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/data/provider/chat_provider.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/bloc/chats_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/widgets/item_chat.dart';
import 'package:inst_project/features/main_screen/features/widgets/app_bar.dart';
import 'package:lottie/lottie.dart';

class ChatsScreenBody extends StatelessWidget {
  const ChatsScreenBody({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatsScreenBloc, ChatsScreenState>(
      buildWhen: (previous, current) => buildWhen(previous, current, context),
      builder: (context, snapshot) {
        List<UserModel> users = context.watch<ChatProvider>().users;

        return Scaffold(
          appBar: const CustomAppBar(
            title: 'Chats',
          ),
          backgroundColor: Colors.grey.withOpacity(0.1),
          body: users.isEmpty
              ? Center(
                  child: Lottie.asset(
                    AnimationAsset.LOADER_AUTH,
                    repeat: true,
                  ),
                )
              : ListView.builder(
                  itemCount: users.length,
                  itemBuilder: (ctx, index) {
                    return ItemChat(
                      user: users[index],
                      onTap: () {
                        BlocProvider.of<ChatsScreenBloc>(context)
                            .add(OpenChat(users[index]));
                      },
                    );
                  },
                ),
        );
      },
    );
  }

  bool buildWhen(
    ChatsScreenState previous,
    ChatsScreenState current,
    BuildContext context,
  ) {
    if (current is AddRoute) {
      Navigator.pushNamed(
        context,
        current.route,
        arguments: current.user,
      );
    }
    return false;
  }
}
