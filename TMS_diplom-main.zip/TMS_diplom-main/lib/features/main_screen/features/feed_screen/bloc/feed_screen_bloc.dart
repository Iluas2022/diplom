import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/data/provider/storage_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/domain/repository/storage/storage_repository.dart';

part 'feed_screen_event.dart';
part 'feed_screen_state.dart';

class FeedScreenBloc extends Bloc<FeedScreenEvent, FeedScreenState> {
  late final StorageRepository _storageRepository;
  FeedScreenBloc({required StorageRepository storageRepository})
      : _storageRepository = storageRepository,
        super(FeedScreenState()) {
    _init();
    on<UpdateFeed>(_updateFeed);
  }

  final StorageProvider _storageProvider = GetIt.I.get<StorageProvider>();
  final UserProvider userProvider = GetIt.I.get<UserProvider>();

  _init() async {
    _storageProvider.clear();
    await Future.delayed(const Duration(seconds: 1));
    final posts = await _storageRepository.getCollection();
    _storageProvider.updatePosts(posts);
  }

  Future _updateFeed(UpdateFeed event, emit) async {
    if (event.feed.post.userIdLike.contains(userProvider.user!.uid)) {
      event.feed.post.userIdLike
          .removeWhere((e) => e == userProvider.user!.uid);
    } else {
      event.feed.post.userIdLike.add(userProvider.user!.uid);
    }

    await _storageRepository.updateFeed(event.feed);
    final posts = await _storageRepository.getCollection();
    _storageProvider.updatePosts(posts);
  }
}
