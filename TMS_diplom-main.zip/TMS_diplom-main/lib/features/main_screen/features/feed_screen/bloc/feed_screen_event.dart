part of 'feed_screen_bloc.dart';

class FeedScreenEvent {}

class UpdateFeed extends FeedScreenEvent {
  Feed feed;

  UpdateFeed(this.feed);
}
