part of 'feed_screen_bloc.dart';

class FeedScreenState {}

class AddRoute extends FeedScreenState {
  String route;

  AddRoute(this.route);
}
