import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/core/di/core_di.dart';
import 'package:inst_project/domain/repository/storage/storage_repository.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/bloc/feed_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/feed_screen_body.dart';

class FeedScreen extends StatelessWidget {
  const FeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<FeedScreenBloc>(
      create: (ctx) => FeedScreenBloc(
        storageRepository: appLocator.get<StorageRepository>(),
      ),
      child: const FeedScreenBody(),
    );
  }
}
