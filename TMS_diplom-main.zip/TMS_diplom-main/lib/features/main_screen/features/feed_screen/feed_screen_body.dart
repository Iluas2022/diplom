import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/constants/animations.dart';
import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/data/provider/storage_provider.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/bloc/feed_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/widgets/grid_feed.dart';
import 'package:inst_project/features/main_screen/features/widgets/app_bar.dart';
import 'package:lottie/lottie.dart';

class FeedScreenBody extends StatelessWidget {
  const FeedScreenBody({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FeedScreenBloc, FeedScreenState>(
      buildWhen: (previous, current) => buildWhen(previous, current, context),
      builder: (context, snapshot) {
        List<Feed> feeds = context.watch<StorageProvider>().posts;
        return Scaffold(
          appBar: const CustomAppBar(
            title: 'Feed',
          ),
          backgroundColor: Colors.grey.withOpacity(0.1),
          body: feeds.isEmpty
              ? Center(
                  child: Lottie.asset(
                    AnimationAsset.LOADER_AUTH,
                    repeat: true,
                  ),
                )
              : GridFeeds(feeds: feeds),
        );
      },
    );
  }

  bool buildWhen(
    FeedScreenState previous,
    FeedScreenState current,
    BuildContext context,
  ) {
    if (current is AddRoute) {
      Navigator.pushNamedAndRemoveUntil(context, current.route, (_) => false);
    }
    return false;
  }
}
