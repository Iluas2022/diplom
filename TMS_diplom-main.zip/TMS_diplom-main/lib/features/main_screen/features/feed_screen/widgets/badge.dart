import 'package:flutter/material.dart';

class BadgeImage extends StatelessWidget {
  final int carouselIndex;
  final int length;
  const BadgeImage({
    super.key,
    required this.carouselIndex,
    required this.length,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topRight,
      child: Container(
        margin: const EdgeInsets.all(10),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.3),
          borderRadius: BorderRadius.circular(100),
        ),
        child: Text(
          '$carouselIndex/$length',
          style: const TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}
