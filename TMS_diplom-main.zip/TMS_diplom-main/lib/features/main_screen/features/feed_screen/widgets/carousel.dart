import 'package:flutter/material.dart';

class CustomCarousel extends StatelessWidget {
  final int length;
  final int currentIndex;

  const CustomCarousel({
    super.key,
    required this.length,
    required this.currentIndex,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 12,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.zero,
        shrinkWrap: true,
        itemCount: length,
        itemBuilder: (ctx, index) {
          return AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              color: index == currentIndex
                  ? Colors.black
                  : Colors.white,
              border: Border.all(
                width: 1,
                color: Colors.black,
              ),
            ),
            height: 12,
            width: 12,
          );
        },
        separatorBuilder: (ctx, index) {
          return const SizedBox(
            width: 10,
          );
        },
      ),
    );
  }
}
