import 'package:flutter/material.dart';
import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/widgets/post.dart';

class GridFeeds extends StatelessWidget {
  final List<Feed> feeds;
  const GridFeeds({
    super.key,
    required this.feeds,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 1,
        mainAxisSpacing: 30,
        childAspectRatio: 2 / 3,
      ),
      itemCount: feeds.length,
      padding: const EdgeInsets.symmetric(vertical: 10),
      addAutomaticKeepAlives: true,
      itemBuilder: (ctx, index) {
        Feed feed = feeds[index];

        return PostWidget(feed: feed);
      },
    );
  }
}
