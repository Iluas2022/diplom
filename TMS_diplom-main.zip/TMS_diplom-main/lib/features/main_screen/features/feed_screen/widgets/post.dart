import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:inst_project/data/models/feed.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/features/main_screen/features/add_screen/widgets/blur_hash.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/bloc/feed_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/widgets/badge.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/widgets/carousel.dart';

class PostWidget extends StatefulWidget {
  final Feed feed;
  const PostWidget({
    super.key,
    required this.feed,
  });

  @override
  State<PostWidget> createState() => _PostWidgetState();
}

class _PostWidgetState extends State<PostWidget> {
  int carouselIndex = 0;
  final UserProvider userProvider = GetIt.I.get<UserProvider>();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(100),
                child: widget.feed.post.userModel!.photo.isEmpty
                    ? const Icon(
                        Icons.person,
                        size: 40,
                      )
                    : Image.network(
                        widget.feed.post.userModel!.photo,
                        fit: BoxFit.cover,
                        height: 40,
                        width: 40,
                      ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  widget.feed.post.userModel!.name.isNotEmpty
                      ? widget.feed.post.userModel!.name
                      : 'Anonimus',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Expanded(
          child: Stack(
            children: [
              PageView.builder(
                itemCount: widget.feed.post.photoPost?.length,
                onPageChanged: (value) {
                  carouselIndex = value;
                  setState(() {});
                },
                itemBuilder: (ctx, index) {
                  PhotoPost photo = widget.feed.post.photoPost![index];
                  return Image.network(
                    photo.url!,
                    fit: BoxFit.cover,
                    loadingBuilder: (BuildContext context, Widget child,
                        ImageChunkEvent? loadingProgress) {
                      if (loadingProgress == null) return child;
                      return CustomBlurHash(blurHash: photo.blurHash);
                    },
                  );
                },
              ),
              if (widget.feed.post.photoPost!.length > 1)
                BadgeImage(
                  carouselIndex: carouselIndex + 1,
                  length: widget.feed.post.photoPost!.length,
                ),
            ],
          ),
        ),
        if (widget.feed.post.photoPost!.length > 1) ...[
          const SizedBox(height: 10),
          CustomCarousel(
            length: widget.feed.post.photoPost!.length,
            currentIndex: carouselIndex,
          ),
        ] else
          const SizedBox(height: 10),
        Row(
          children: [
            IconButton(
              onPressed: () {
                BlocProvider.of<FeedScreenBloc>(context)
                    .add(UpdateFeed(widget.feed));
              },
              icon: widget.feed.post.userIdLike.contains(userProvider.user?.uid)
                  ? const Icon(
                      Icons.favorite,
                      color: Colors.red,
                    )
                  : const Icon(Icons.favorite_border),
            ),
            if (widget.feed.post.userIdLike.isNotEmpty)
              Text('${widget.feed.post.userIdLike.length} Likes'),
          ],
        ),
        if (widget.feed.post.title!.isNotEmpty) ...[
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text(
                widget.feed.post.title ?? '',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w300,
                ),
              ),
            ),
          ),
        ],
        const Divider(),
      ],
    );
  }
}
