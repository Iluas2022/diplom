import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/router.dart';

part 'profile_screen_event.dart';
part 'profile_screen_state.dart';

class ProfileScreenBloc extends Bloc<ProfileScreenEvent, ProfileScreenState> {
  final UserProvider _userProvider;
  final LocalSecureStorageProvider _secureStorageProvider;

  ProfileScreenBloc({
    required UserProvider userProvider,
    required LocalSecureStorageProvider secureStorageProvider,
  })  : _userProvider = userProvider,
        _secureStorageProvider = secureStorageProvider,
        super(ProfileScreenState()) {
    on<LogOut>(_logOut);
  }

  _logOut(event, emit) async {
    _userProvider.logOut();
    await _secureStorageProvider.deleteAll();
    emit(ProfileScreenRoute(Router.splashScreenPage));
  }
}
