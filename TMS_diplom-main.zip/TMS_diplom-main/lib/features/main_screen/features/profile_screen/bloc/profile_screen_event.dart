part of 'profile_screen_bloc.dart';

class ProfileScreenEvent {}

class LogOut extends ProfileScreenEvent {}
