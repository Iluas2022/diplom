part of 'profile_screen_bloc.dart';

class ProfileScreenState {}

class ProfileScreenRoute extends ProfileScreenState {
  String route;

  ProfileScreenRoute(this.route);
}
