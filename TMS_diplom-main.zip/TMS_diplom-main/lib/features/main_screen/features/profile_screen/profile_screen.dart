import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/core/di/core_di.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/features/main_screen/features/profile_screen/bloc/profile_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/profile_screen/profile_screen_body.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<ProfileScreenBloc>(
      create: (ctx) => ProfileScreenBloc(
        userProvider: appLocator.get<UserProvider>(),
        secureStorageProvider: appLocator.get<LocalSecureStorageProvider>(),
      ),
      child: const ProfileScreenBody(),
    );
  }
}
