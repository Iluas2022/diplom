import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/features/main_screen/features/profile_screen/bloc/profile_screen_bloc.dart';
import 'package:inst_project/features/main_screen/features/profile_screen/widgets/button_exit.dart';
import 'package:inst_project/features/main_screen/features/profile_screen/widgets/user_avatar.dart';
import 'package:inst_project/features/main_screen/features/profile_screen/widgets/user_info.dart';
import 'package:inst_project/features/main_screen/features/widgets/app_bar.dart';

class ProfileScreenBody extends StatelessWidget {
  const ProfileScreenBody({super.key});

  @override
  Widget build(BuildContext context) {
    final UserProvider userProvider = GetIt.I.get<UserProvider>();

    return BlocBuilder<ProfileScreenBloc, ProfileScreenState>(
      buildWhen: (previous, current) => buildWhen(previous, current, context),
      builder: (context, snapshot) {
        return Scaffold(
          appBar: const CustomAppBar(
            title: 'Profile',
          ),
          backgroundColor: Colors.grey.withOpacity(0.1),
          body: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              if (userProvider.user != null) ...[
                UserAvatar(photoLink: userProvider.user!.photo),
                const SizedBox(height: 20),
                UserInfo(userModel: userProvider.user!),
              ],
              const SizedBox(height: 30),
              ButtonExit(
                title: 'Log out',
                onPressed: () {
                  BlocProvider.of<ProfileScreenBloc>(context).add(LogOut());
                },
              ),
              const SizedBox(height: 50),
            ],
          ),
        );
      },
    );
  }

  bool buildWhen(
    ProfileScreenState previous,
    ProfileScreenState current,
    BuildContext context,
  ) {
    if (current is ProfileScreenRoute) {
      Navigator.pushNamedAndRemoveUntil(context, current.route, (_) => false);
    }
    return false;
  }
}
