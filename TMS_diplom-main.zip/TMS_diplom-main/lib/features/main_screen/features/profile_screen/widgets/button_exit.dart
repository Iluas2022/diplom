import 'package:flutter/material.dart';

class ButtonExit extends StatelessWidget {
  final String title;
  final Function()? onPressed;
  const ButtonExit({
    super.key,
    required this.title,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        backgroundColor: Colors.red,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(12)),
        ),
      ).copyWith(
        side: WidgetStateProperty.resolveWith<BorderSide?>(
          (Set<WidgetState> states) {
            if (states.contains(WidgetState.pressed)) {
              return const BorderSide(
                color: Colors.red,
                width: 2,
              );
            }
            return null;
          },
        ),
      ),
      onPressed: onPressed,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
            ),
          ),
          const SizedBox(width: 10),
          const Icon(
            Icons.exit_to_app,
            color: Colors.white,
          ),
        ],
      ),
    );
  }
}
