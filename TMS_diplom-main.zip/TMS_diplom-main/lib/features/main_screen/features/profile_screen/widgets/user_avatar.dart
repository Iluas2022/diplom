import 'package:flutter/material.dart';

class UserAvatar extends StatelessWidget {
  final String photoLink;
  const UserAvatar({
    super.key,
    required this.photoLink,
  });

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: 100,
      child: SizedBox(
        height: 170,
        width: 170,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(100),
          child: photoLink.isEmpty
              ? const Icon(
                  Icons.person,
                  size: 70,
                )
              : Image.network(
                  photoLink,
                  fit: BoxFit.cover,
                  loadingBuilder: (BuildContext context, Widget child,
                      ImageChunkEvent? loadingProgress) {
                    if (loadingProgress == null) return child;
                    return const CircularProgressIndicator();
                  },
                ),
        ),
      ),
    );
  }
}
