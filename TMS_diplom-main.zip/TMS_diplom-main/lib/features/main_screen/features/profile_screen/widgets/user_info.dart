import 'package:flutter/material.dart';
import 'package:inst_project/data/models/user_model.dart';

class UserInfo extends StatelessWidget {
  final UserModel userModel;
  const UserInfo({
    super.key,
    required this.userModel,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          if (userModel.name.isNotEmpty)
            Text(
              userModel.name,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w700,
              ),
            ),
          if (userModel.email.isNotEmpty)
            Text(
              'E-mail: ${userModel.email}',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w400,
              ),
            ),
          if (userModel.phone.isNotEmpty)
            Text(
              'Phone: ${userModel.phone}',
              textAlign: TextAlign.center,
            ),
        ],
      ),
    );
  }
}
