import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/features/main_screen/bloc/main_screen_bloc.dart';
import 'package:inst_project/features/main_screen/main_screen_body.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<MainScreenBloc>(
      create: (ctx) => MainScreenBloc(),
      child: const MainScreenBody(),
    );
  }
}
