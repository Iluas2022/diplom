import 'package:flutter/material.dart';
import 'package:inst_project/features/main_screen/features/add_screen/add_screen.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/chats_screen.dart';
import 'package:inst_project/features/main_screen/features/feed_screen/feed_screen.dart';
import 'package:inst_project/features/main_screen/features/profile_screen/profile_screen.dart';
import 'package:inst_project/router.dart' as router;

class MainScreenBody extends StatefulWidget {
  const MainScreenBody({super.key});

  @override
  State<MainScreenBody> createState() => _MainScreenBodyState();
}

class _MainScreenBodyState extends State<MainScreenBody> {
  int currentIndex = 0;

  onTapNavigationBar(int value) {
    if (value == 1) {
      Navigator.of(context).pushNamed(router.Router.addPage);
    } else {
      currentIndex = value;
      setState(() {});
    }
  }

  List<Widget> pages = [
    const FeedScreen(),
    const AddScreen(),
    const ChatsScreen(),
    const ProfileScreen(),
  ];

  List<BottomNavigationBarItem> barItems = const [
    BottomNavigationBarItem(
      label: 'Feed',
      icon: Icon(Icons.search),
    ),
    BottomNavigationBarItem(
      label: 'Add',
      icon: Icon(Icons.add_circle_outline_sharp),
    ),
    BottomNavigationBarItem(
      label: 'Chats',
      icon: Icon(Icons.chat_bubble_outline),
    ),
    BottomNavigationBarItem(
      label: 'Profile',
      icon: Icon(Icons.person),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.black.withOpacity(0.5),
        unselectedLabelStyle: TextStyle(color: Colors.black.withOpacity(0.5)),
        selectedLabelStyle: const TextStyle(color: Colors.black),
        iconSize: 26,
        onTap: onTapNavigationBar,
        items: barItems,
      ),
    );
  }
}
