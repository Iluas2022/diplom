import 'dart:convert';
import 'dart:developer';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/router.dart';

part 'splash_screen_event.dart';
part 'splash_screen_state.dart';

class SplashScreenBloc extends Bloc<SplashScreenEvent, SplashScreenState> {
  late final LocalSecureStorageProvider _secureStorageProvider;
  late final UserProvider _userProvider;
  SplashScreenBloc({
    required LocalSecureStorageProvider secureStorageProvider,
    required UserProvider userProvider,
  })  : _secureStorageProvider = secureStorageProvider,
        _userProvider = userProvider,
        super(SplashScreenState()) {
    _init();
  }

  _init() async {
    try {
      String? user = await _secureStorageProvider.getUser();
      if (user != null) {
        await Future.delayed(const Duration(seconds: 2));
        UserModel userModel = UserModel.fromJson(jsonDecode(user));
        _userProvider.setUser(userModel);
        emit(SplashScreenRoute(Router.mainPage));
      } else {
        await Future.delayed(const Duration(seconds: 2));
        emit(SplashScreenRoute(Router.authPage));
      }
    } catch (e) {
      emit(SplashScreenRoute(Router.authPage));
      log('_init() error $e');
    }
  }
}
