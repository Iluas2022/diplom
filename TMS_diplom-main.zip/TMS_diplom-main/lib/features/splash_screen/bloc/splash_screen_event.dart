part of 'splash_screen_bloc.dart';

class SplashScreenEvent {}

class SplashScreenInit extends SplashScreenEvent {}
