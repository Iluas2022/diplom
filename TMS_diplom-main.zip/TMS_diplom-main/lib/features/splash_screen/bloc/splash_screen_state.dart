part of 'splash_screen_bloc.dart';

class SplashScreenState {}

class SplashScreenRoute extends SplashScreenState {
  String route;

  SplashScreenRoute(this.route);
}
