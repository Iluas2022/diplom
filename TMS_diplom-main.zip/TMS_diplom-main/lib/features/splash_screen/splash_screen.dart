import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/core/di/core_di.dart';
import 'package:inst_project/data/provider/local_storage_provider.dart';
import 'package:inst_project/data/provider/user_provider.dart';
import 'package:inst_project/features/splash_screen/bloc/splash_screen_bloc.dart';
import 'package:inst_project/features/splash_screen/splash_screen_body.dart';

class SplashScreenPage extends StatelessWidget {
  const SplashScreenPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<SplashScreenBloc>(
      create: (ctx) => SplashScreenBloc(
        secureStorageProvider: appLocator.get<LocalSecureStorageProvider>(),
        userProvider: appLocator.get<UserProvider>(),
      ),
      child: const SplashScreenBody(),
    );
  }
}
