import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:inst_project/constants/animations.dart';
import 'package:inst_project/features/splash_screen/bloc/splash_screen_bloc.dart';
import 'package:lottie/lottie.dart';

class SplashScreenBody extends StatelessWidget {
  const SplashScreenBody({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SplashScreenBloc, SplashScreenState>(
      buildWhen: (previous, current) => buildWhen(previous, current, context),
      builder: (context, snapshot) {
        return Scaffold(
          body: Center(
            child: Lottie.asset(
              AnimationAsset.ANIM_LOADER,
              repeat: true,
            ),
          ),
        );
      },
    );
  }

  bool buildWhen(
    SplashScreenState previous,
    SplashScreenState current,
    BuildContext context,
  ) {
    if (current is SplashScreenRoute) {
      Navigator.pushNamedAndRemoveUntil(context, current.route, (_) => false);
    }
    return false;
  }
}
