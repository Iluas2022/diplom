import 'package:flutter/material.dart';
import 'package:inst_project/data/models/user_model.dart';
import 'package:inst_project/features/auth_screen/auth_screen.dart';
import 'package:inst_project/features/auth_screen/sign_in_email_password.dart';
import 'package:inst_project/features/auth_screen/sign_up_email_password.dart';
import 'package:inst_project/features/main_screen/features/add_screen/add_screen.dart';
import 'package:inst_project/features/main_screen/features/chats_screen/chat_screen/chat_screen.dart';
import 'package:inst_project/features/main_screen/main_screen.dart';
import 'package:inst_project/features/splash_screen/splash_screen.dart';

class Router {
  static const String splashScreenPage = '/';
  static const String authPage = '/auth';
  static const String mainPage = '/main';
  static const String chatPage = '/chat';
  static const String addPage = '/add';
  static const String signUp = '/auth/signUp';
  static const String signIn = '/auth/signIn';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splashScreenPage:
        return MaterialPageRoute(builder: (_) => const SplashScreenPage());
      case authPage:
        return MaterialPageRoute(builder: (_) => const AuthScreen());
      case signUp:
        return MaterialPageRoute(
            builder: (_) => const SignUpEmailPasswordScreen());
      case signIn:
        return MaterialPageRoute(
            builder: (_) => const SignInEmailPasswordScreen());
      case mainPage:
        return MaterialPageRoute(builder: (_) => const MainScreen());
      case addPage:
        return MaterialPageRoute(builder: (_) => const AddScreen());
      case chatPage:
        UserModel user = settings.arguments as UserModel;
        return MaterialPageRoute(builder: (_) => ChatScreen(user: user));
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text(
                'No route defined for ${settings.name}',
              ),
            ),
          ),
        );
    }
  }
}
